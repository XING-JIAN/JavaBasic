package practice02;
/*
 * PTra02_08.java
 *   作成	LIKEIT	2017
 *------------------------------------------------------------
 * Copyright(c) Rhizome Inc. All Rights Reserved.
 */

public class PTra02_08 {
	public static void main(String[] args) {
		int num = 20;
		int calc = 5;
		String name = "鈴木";

		// ★ 変数num, calc, nameを連結して「鈴木さんは、25歳になりました」を出力してください


	}
}
