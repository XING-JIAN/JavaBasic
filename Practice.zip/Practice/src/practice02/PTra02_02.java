package practice02;
/*
 * PTra02_02.java
 *   作成	LIKEIT	2017
 *------------------------------------------------------------
 * Copyright(c) Rhizome Inc. All Rights Reserved.
 */

public class PTra02_02 {
	public static void main(String[] args) {
		int num = 10;
		System.out.println(num);

		// ★ 変数numの値に30足した数を出力してください


		// ★ 以下のプログラムで40が出力されるようにしてください
		System.out.println(num);	// ※※ この行は修正しないでください
	}
}
