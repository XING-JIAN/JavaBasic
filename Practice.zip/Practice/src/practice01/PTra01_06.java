package practice01;
/*
 * PTra01_06.java
 *   作成	LIKEIT	2017
 *------------------------------------------------------------
 * Copyright(c) Rhizome Inc. All Rights Reserved.
 */

public class PTra01_06 {
	public static void main(String[] args) {

		// ★ 文字列を格納する変数 str を宣言してください


		// ★ 変数 str に自分の名前を代入してください


		// ★ 変数 str の中身を出力してください


	}
}
