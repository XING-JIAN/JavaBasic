package practice01;
/*
 * PTra01_03.java
 *   作成	LIKEIT	2017
 *------------------------------------------------------------
 * Copyright(c) Rhizome Inc. All Rights Reserved.
 */

public class PTra01_03 {
	public static void main(String[] args) {

		// ★ int型の変数 i を宣言してください


		// ★ 変数 i に 10 を代入してください


		// ★ 変数 i に入っている値を出力してください
		System.out.println(i);

	}
}
